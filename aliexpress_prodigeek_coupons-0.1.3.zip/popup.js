function getPageCartTotal() {
   
    const checkoutSubtotalSelector = '.pl-summary__item-content-pc[data-pl="pl-summary-content"]';
   
    const cartTotalSelector = '.cart-summary-item-wrapStyle-content';
   
    const oldCheckoutTotalSelector = '.pl-order-toal-container__item-content, [data-pl="checkout-total"] .total-price';
    
    const selectors = [checkoutSubtotalSelector, cartTotalSelector, oldCheckoutTotalSelector];
    
    for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element && element.innerText) {
           
            const priceText = element.innerText.replace(/[€$]/g, '').replace(',', '.').trim();
            const price = parseFloat(priceText);
            if (!isNaN(price)) {
                return price;
            }
        }
    }
    
    return 0;
}


function renderCouponList(coupons, container) {
    container.innerHTML = '';
    const titleHeader = document.createElement('h2');
    titleHeader.className = 'category-title';
    titleHeader.textContent = 'Coupon Applicabili';
    container.appendChild(titleHeader);

    if (coupons.length === 0) {
        container.innerHTML += '<div class="status-message">Nessun coupon applicabile per questo totale.</div>';
        return;
    }
    coupons.forEach(coupon => container.appendChild(createCouponCard(coupon)));
}


function renderCategorizedList(categories, container, categoryTitles = {}) {
    container.innerHTML = '';

    let hasCoupons = false;
    for (const categoryKey in categories) {
        const couponList = categories[categoryKey];
        if (couponList.length > 0) {
            hasCoupons = true;
            const categoryName = categoryTitles[categoryKey] || categoryKey;
            const categoryHeader = document.createElement('h2');
            categoryHeader.className = 'category-title';
            categoryHeader.textContent = categoryName;
            container.appendChild(categoryHeader);
            couponList.forEach(coupon => container.appendChild(createCouponCard(coupon)));
        }
    }
    if (!hasCoupons) {
        container.innerHTML = '<div class="status-message">Nessun coupon disponibile al momento.</div>';
    }
}

function createCouponCard(coupon) {
    const card = document.createElement('div');
    card.className = 'coupon-card';

    const percentage = coupon.min > 0 ? Math.round((coupon.discount / coupon.min) * 100) : 0;

   
    const couponHeader = document.createElement('div');
    couponHeader.className = 'coupon-header';

    const discountValue = document.createElement('div');
    discountValue.className = 'discount-value';
    discountValue.textContent = coupon.discount;
    const currencySpan = document.createElement('span');
    currencySpan.textContent = coupon.currency;
    discountValue.appendChild(currencySpan);
    couponHeader.appendChild(discountValue);

    if (percentage > 0) {
        const percentageDiv = document.createElement('div');
        percentageDiv.className = 'percentage';
        percentageDiv.textContent = `~${percentage}% OFF`;
        couponHeader.appendChild(percentageDiv);
    }
    card.appendChild(couponHeader);

   
    const couponDetails = document.createElement('div');
    couponDetails.className = 'coupon-details';
    couponDetails.textContent = `Sconto su spesa minima di ${coupon.min}${coupon.currency}`;
    card.appendChild(couponDetails);

   
    const codeContainer = document.createElement('div');
    codeContainer.className = 'coupon-code-container';
    codeContainer.title = 'Copia il codice';
    
    const couponCodeText = document.createElement('span');
    couponCodeText.className = 'coupon-code';
    couponCodeText.textContent = coupon.code;
    codeContainer.appendChild(couponCodeText);

    const copyFeedback = document.createElement('div');
    copyFeedback.className = 'copy-feedback';
    copyFeedback.textContent = 'Copiato!';
    copyFeedback.style.display = 'none';
    codeContainer.appendChild(copyFeedback);
    
    card.appendChild(codeContainer);

   
    codeContainer.addEventListener('click', () => {
        navigator.clipboard.writeText(coupon.code).then(() => {
            couponCodeText.style.display = 'none';
            copyFeedback.style.display = 'block';
            
            card.classList.add('copy-animation');
            card.addEventListener('animationend', () => card.classList.remove('copy-animation'), { once: true });

            setTimeout(() => {
                couponCodeText.style.display = 'block';
                copyFeedback.style.display = 'none';
            }, 2000);
        }).catch(err => { /* console.error('Failed to copy code: ', err) */ });
    });

    return card;
}

async function initializePopup() {
    const couponListContainer = document.getElementById('coupon-list');
    const titleElement = document.querySelector('.title');
    
    const storedData = await chrome.storage.local.get(['coupons', 'eurToUsdRate', 'categoryTitles']);
    const allCouponsByCategory = storedData.coupons;
    const eurToUsdRate = storedData.eurToUsdRate;
    const categoryTitles = storedData.categoryTitles;

    if (!allCouponsByCategory) {
        couponListContainer.innerHTML = '<div class="status-message">Coupon non ancora caricati. Riprova tra un istante.</div>';
        return;
    }

    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const isOnAliExpressCart = activeTab.url && (activeTab.url.includes('shoppingcart') || activeTab.url.includes('trade/confirm'));

    if (isOnAliExpressCart) {
        try {
            const injectionResults = await chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: getPageCartTotal,
            });

            const cartTotalEUR = injectionResults[0].result;
            
            if (cartTotalEUR > 0 && eurToUsdRate) {
                if (titleElement) titleElement.textContent = 'Coupon Applicabili';
                
                const cartTotalUSD = cartTotalEUR * eurToUsdRate;
                
                const allCouponsFlat = Object.values(allCouponsByCategory).flat();
                
                const applicableCoupons = allCouponsFlat.filter(c => {
                    if (c.currency === '€' || c.currency === 'EUR') {
                        return cartTotalEUR >= c.min;
                    } else if (c.currency === '$' || c.currency === 'USD') {
                        return cartTotalUSD >= c.min;
                    }
                    return false;
                });

                applicableCoupons.sort((a, b) => {
                    const discountA = (a.currency === '$' || a.currency === 'USD') ? a.discount / eurToUsdRate : a.discount;
                    const discountB = (b.currency === '$' || b.currency === 'USD') ? b.discount / eurToUsdRate : a.discount;
                    return discountB - discountA;
                });

                renderCouponList(applicableCoupons, couponListContainer);

            } else {
                // No currency rate available
                const allCouponsFlat = Object.values(allCouponsByCategory).flat();
                const applicableCoupons = allCouponsFlat.filter(c => {
                    return cartTotalEUR >= c.min;
                });
                applicableCoupons.sort((a, b) => b.discount - a.discount);
                renderCouponList(applicableCoupons, couponListContainer);
            }
        } catch (e) {
            /* console.error("Failed to inject script or process cart total:", e); */
            renderCategorizedList(allCouponsByCategory, couponListContainer, categoryTitles);
        }
    } else {
        renderCategorizedList(allCouponsByCategory, couponListContainer, categoryTitles);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initializePopup();

    const reloadButton = document.getElementById('reload-data-button');
    if (reloadButton) {
        reloadButton.addEventListener('click', async () => {
            reloadButton.textContent = 'Caricamento...';
            reloadButton.disabled = true;
            
            try {
               
                await chrome.runtime.sendMessage({ action: 'updateData' });
               
                await initializePopup();
            } catch (e) {
                console.error('Error reloading data:', e);
               
            } finally {
                reloadButton.textContent = 'Ricarica Coupon';
                reloadButton.disabled = false;
            }
        });
    }
});