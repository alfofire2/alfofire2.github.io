const COUPON_URL = 'https://coupon.prodigeek.it/';
const ALARM_NAME = 'refresh-data';

// Data fetching and storage logic
async function updateData() {
    let dataToStore = {};
    try {
        const [couponResponse, currencyResponse] = await Promise.all([
            fetch(COUPON_URL).catch(e => ({ error: 'coupon-fetch', e })),
            fetch('https://api.frankfurter.dev/v1/latest', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'symbols=USD'
            }).catch(e => ({ error: 'currency-fetch', e }))
        ]);

        if (couponResponse && couponResponse.ok) {
            const html = await couponResponse.text();
            const match = html.match(/const coupons = (\{[\s\S]*?\});/);
            if (match && match[1]) {
                try {
                    // Convert the JS object string to a valid JSON string
                    let jsonString = match[1]
                        // Add quotes around unquoted keys
                        .replace(/([{,]\s*)(\w+)\s*:/g, '$1"$2":')
                        // Replace single quotes with double quotes
                        .replace(/'/g, '"');
                    
                    dataToStore.coupons = JSON.parse(jsonString);
                } catch (e) {
                    /* console.error('[Background] Failed to parse coupon JSON string:', e); */
                }
            } else {
                /* console.error('[Background] Could not find coupons object in fetched HTML.'); */
            }
        } else {
            /* console.error(`[Background] Coupon fetch failed:`, couponResponse ? couponResponse.statusText : 'Unknown Error'); */
        }

        if (currencyResponse && currencyResponse.ok) {
            const data = await currencyResponse.json();
            if (data.rates && data.rates.USD) {
                dataToStore.eurToUsdRate = data.rates.USD;
            } else {
                /* console.error('[Background] Could not find USD rate in API response.'); */
            }
        } else {
            /* console.error(`[Background] Currency fetch failed:`, currencyResponse ? currencyResponse.statusText : 'Unknown Error'); */
        }

        if (Object.keys(dataToStore).length > 0) {
            chrome.storage.local.set(dataToStore);
        } else {
            // No new data
        }
    } catch (error) {
        /* console.error('[Background] General error in updateData:', error); */
    }
}

// Message listener for popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getData') {
        chrome.storage.local.get(['coupons', 'eurToUsdRate'], (storedData) => {
            if (chrome.runtime.lastError) {
                /* console.error(chrome.runtime.lastError); */
                sendResponse({ error: "Failed to get data" });
                return;
            }
            if (!storedData.coupons || !storedData.eurToUsdRate) {
                updateData().then(newData => sendResponse(newData));
            } else {
                sendResponse(storedData);
            }
        });
        return true; // Indicates an asynchronous response
    } else if (message.action === 'updateData') {
        updateData().then(newData => sendResponse(newData));
        return true; // Indicates an asynchronous response
    } else if (message.action === 'openAffiliateTab') {
        // Check if the resolved affiliate tab already exists
        chrome.tabs.query({ url: "*://*.aliexpress.com/*_c3j3Yy8x*" }, (tabs) => {
            if (tabs.length === 0) {
                // If it doesn't exist, create it with the short URL
                chrome.tabs.create({ url: message.url, pinned: true, active: false });
            }
            // If it exists, do nothing.
        });
    }
});

// Standard extension lifecycle events
chrome.runtime.onInstalled.addListener(() => {
    updateData();
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: 15 });
});

chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === ALARM_NAME) {
        updateData();
    }
});