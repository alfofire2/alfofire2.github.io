// =================================================================================
// STYLING
// =================================================================================

const injectedCSS = `
    :root {
        --orange: #e47b2c;
        --turquoise: #60b3b0;
        --creamy-white: #fffffb;
        --dark-grey: #2c3e50;
        --light-grey: #ecf0f1;
        --white: #ffffff;
    }

    #ali-coupon-helper-overlay {
        position: fixed;
        top: 20px;
        right: 20px;
        width: 380px;
        height: 80vh;
        max-height: 700px;
        background-color: var(--creamy-white);
        border-radius: 12px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        z-index: 10000;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .ach-header {
        flex-shrink: 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 20px;
        border-bottom: 1px solid var(--light-grey);
        background-color: var(--white);
    }

    .ach-title {
        font-size: 1.1em;
        font-weight: 700;
        color: var(--orange);
    }

    .ach-close {
        font-size: 28px;
        font-weight: 300;
        color: #aaa;
        cursor: pointer;
        line-height: 1;
        transition: color .2s;
    }
    .ach-close:hover {
        color: var(--dark-grey);
    }

    .ach-body {
        flex-grow: 1;
        padding: 15px;
        overflow-y: auto;
        background-color: var(--creamy-white);
    }
    
    .ach-no-coupons {
        text-align: center;
        padding: 40px 20px;
        color: var(--dark-grey);
        font-size: 1em;
    }

    .ach-card {
        background-color: var(--white);
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .ach-discount {
        font-size: 2em;
        font-weight: 700;
        color: var(--dark-grey);
        line-height: 1;
        flex-shrink: 0;
        width: 80px;
    }
    
    .ach-discount span {
        font-size: 0.5em;
        font-weight: 400;
    }

    .ach-details {
        flex-grow: 1;
    }

    .ach-code {
        font-family: "Consolas", "Courier New", monospace;
        font-weight: bold;
        font-size: 1.2em;
        color: var(--turquoise);
        margin-bottom: 5px;
    }

    .ach-min {
        font-size: 0.85em;
        color: #7f8c8d;
    }

    .ach-apply {
        background-color: var(--orange);
        color: white;
        border: none;
        padding: 10px 16px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.2s, transform 0.2s;
        flex-shrink: 0;
    }

    .ach-apply:hover {
        background-color: #d36a1b;
        transform: scale(1.05);
    }
`;

// =================================================================================
// UI & LOGIC
// =================================================================================

function showReopenButton() {
    if (document.getElementById('ali-coupon-helper-reopen')) return;
    const reopenButton = document.createElement('div');
    reopenButton.id = 'ali-coupon-helper-reopen';
    const imgElement = document.createElement('img');
    imgElement.src = chrome.runtime.getURL('icons/icon48.png');
    imgElement.alt = 'Riapri Coupon';
    reopenButton.appendChild(imgElement);
    reopenButton.style.cssText = `position:fixed;top:20px;right:20px;width:50px;height:50px;background-color:#fff;border-radius:50%;box-shadow:0 4px 12px rgba(0,0,0,0.15);cursor:pointer;z-index:9998;display:flex;justify-content:center;align-items:center;transition:transform .2s;`;
    reopenButton.querySelector('img').style.cssText = 'width:32px;height:32px;';
    reopenButton.addEventListener('mouseover', () => reopenButton.style.transform = 'scale(1.1)');
    reopenButton.addEventListener('mouseout', () => reopenButton.style.transform = 'scale(1.0)');
    reopenButton.addEventListener('click', () => { reopenButton.remove(); main(); });
    document.body.appendChild(reopenButton);
}

function createCouponCardElement(coupon) {
    const card = document.createElement('div');
    card.className = 'ach-card';

   
    const discount = document.createElement('div');
    discount.className = 'ach-discount';
    discount.textContent = coupon.discount;
    const currencySpan = document.createElement('span');
    currencySpan.textContent = coupon.currency;
    discount.appendChild(currencySpan);
    card.appendChild(discount);

   
    const details = document.createElement('div');
    details.className = 'ach-details';
    const code = document.createElement('div');
    code.className = 'ach-code';
    code.textContent = coupon.code;
    details.appendChild(code);
    const min = document.createElement('div');
    min.className = 'ach-min';
    min.textContent = `Spesa minima: ${coupon.min}${coupon.currency}`;
    details.appendChild(min);
    card.appendChild(details);

   
    const applyButton = document.createElement('button');
    applyButton.className = 'ach-apply';
    applyButton.dataset.code = coupon.code;
    applyButton.textContent = 'Applica';
    applyButton.addEventListener('click', () => {
        // First, open the affiliate tab in the background
        chrome.runtime.sendMessage({ action: 'openAffiliateTab', url: 'https://s.click.aliexpress.com/e/_c3j3Yy8x' });
        
        // Then, apply the coupon to the current page
        applyCoupon(coupon.code);
    });
    card.appendChild(applyButton);

    return card;
}

function createCouponOverlay(applicableCoupons) {
    const overlay = document.createElement('div');
    overlay.id = 'ali-coupon-helper-overlay';

   
    const style = document.createElement('style');
    style.textContent = injectedCSS;
    overlay.appendChild(style);

   
    const header = document.createElement('div');
    header.className = 'ach-header';
    const title = document.createElement('span');
    title.className = 'ach-title';
    title.textContent = 'Coupon Applicabili';
    header.appendChild(title);
    const closeButton = document.createElement('span');
    closeButton.className = 'ach-close';
    closeButton.innerHTML = '&times;';
    closeButton.addEventListener('click', () => { overlay.remove(); showReopenButton(); });
    header.appendChild(closeButton);
    overlay.appendChild(header);

   
    const body = document.createElement('div');
    body.className = 'ach-body';
    if (applicableCoupons.length > 0) {
        applicableCoupons.forEach(coupon => {
            body.appendChild(createCouponCardElement(coupon));
        });
    } else {
        const noCoupons = document.createElement('p');
        noCoupons.className = 'ach-no-coupons';
        noCoupons.textContent = 'Nessun coupon applicabile per questo totale.';
        body.appendChild(noCoupons);
    }
    overlay.appendChild(body);
    
    return overlay;
}

function main() {
    if (document.getElementById('ali-coupon-helper-overlay')) return;


    chrome.runtime.sendMessage({ action: 'getData' }, (storedData) => {
        if (chrome.runtime.lastError) {
            /* console.error('[ACH] Error receiving data from background script:', chrome.runtime.lastError); */
            return;
        }
        
        if (!storedData || !storedData.coupons) {
            /* console.error('[ACH] Did not receive valid coupon data from background script.'); */
            return;
        }


        const cartTotalEUR = getPageCartTotal();
        if (cartTotalEUR === 0) {
    
            return;
        }

        const allCouponsFlat = Object.values(storedData.coupons).flat();
        const eurToUsdRate = storedData.eurToUsdRate;
        let applicableCoupons = [];

        if (eurToUsdRate) {
            const cartTotalUSD = cartTotalEUR * eurToUsdRate;
            applicableCoupons = allCouponsFlat.filter(c => {
                if (c.currency === '€' || c.currency === 'EUR') {
                    return cartTotalEUR >= c.min;
                } else if (c.currency === '$' || c.currency === 'USD') {
                    return cartTotalUSD >= c.min;
                }
                return false;
            });

            applicableCoupons.sort((a, b) => {
                const discountA = (a.currency === '$' || a.currency === 'USD') ? a.discount / eurToUsdRate : a.discount;
                const discountB = (b.currency === '$' || b.currency === 'USD') ? b.discount / eurToUsdRate : b.discount;
                return discountB - discountA;
            });
        } else {

            applicableCoupons = allCouponsFlat.filter(c => {
                return cartTotalEUR >= c.min;
            });
            applicableCoupons.sort((a, b) => b.discount - a.discount);
        }

        if (applicableCoupons.length > 0) {
            const couponOverlay = createCouponOverlay(applicableCoupons);
            document.body.appendChild(couponOverlay);
        }
    });
}

// =================================================================================
// UTILS & TRIGGERS
// =================================================================================

function getPageCartTotal() {
    const summaryItems = document.querySelectorAll('.pl-summary__item-pc');
    for (const item of summaryItems) {
        const titleElement = item.querySelector('.pl-summary__item-title__main');
        if (titleElement && titleElement.innerText.toLowerCase().includes('subtotale')) {
            const contentElement = item.querySelector('.pl-summary__item-content-pc');
            if (contentElement && contentElement.innerText) {
                const priceText = contentElement.innerText.replace(/[€$]/g, '').replace(',', '.').trim();
                const price = parseFloat(priceText);
                if (!isNaN(price)) {

                    return price;
                }
            }
        }
    }
    /* console.log('[ACH] Could not find subtotal element.'); */
    return 0;
}

function openPromoBox() {
    return new Promise((resolve) => {
        const inputElement = document.querySelector('input[class*="promoCode-input"]');
        if (inputElement && inputElement.offsetParent !== null) {
            return resolve();
        }

        const promoArrowElements = document.getElementsByClassName("pl-summary__item-arrow-pc");
        let correctPromoArrow = null;
        const keywords = ['promo', 'codice', 'code', 'coupon'];

        for (let i = 0; i < promoArrowElements.length; i++) {
            const arrowElement = promoArrowElements[i];
            const parentSummaryItem = arrowElement.closest('.pl-summary__item-pc');
            if (parentSummaryItem && keywords.some(k => parentSummaryItem.innerText.toLowerCase().includes(k))) {
                correctPromoArrow = arrowElement;
                break;
            }
        }

        if (correctPromoArrow) {
            const observer = new MutationObserver((mutations, obs) => {
                const inputNowVisible = document.querySelector('input[class*="promoCode-input"]');
                if (inputNowVisible && inputNowVisible.offsetParent !== null) {
                    obs.disconnect();
                    resolve();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });
            correctPromoArrow.click();
            setTimeout(() => { observer.disconnect(); resolve(); }, 3000);
        } else {
            /* console.error('[ACH] Could not find the correct promo arrow to click.'); */
            resolve(); 
        }
    });
}

async function applyCoupon(code) {
    /* console.log('[ACH] applyCoupon: Starting for code:', code); */
    await openPromoBox();

    const inputElement = document.querySelector('input[class*="promoCode-input"]');
    if (!inputElement || inputElement.offsetParent === null) {
        /* console.error('[ACH] applyCoupon: Input element not found or not visible.'); */
        return;
    }

    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(inputElement, code);
    inputElement.dispatchEvent(new Event('input', { bubbles: true }));
    /* console.log('[ACH] applyCoupon: Set value and dispatched input event.'); */

    /* console.log('[ACH] applyCoupon: Simulating ArrowDown key press.'); */
    inputElement.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', bubbles: true }));
    inputElement.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', code: 'ArrowDown', bubbles: true }));

    await new Promise(resolve => setTimeout(resolve, 500));

    const applyButton = document.querySelector('button[class*="promoCode-input-button"]');
    if (applyButton && !applyButton.disabled) {
        /* console.log('[ACH] applyCoupon: Apply button is enabled. Clicking.'); */
        applyButton.click();
        const overlay = document.getElementById('ali-coupon-helper-overlay');
        if (overlay) {
            overlay.remove();
            showReopenButton();
        }
    } else {
        /* console.error('[ACH] applyCoupon: Apply button not found or is still disabled.'); */
    }
}

const pageObserver = new MutationObserver((mutations, obs) => {
    if (!window.location.href.includes('trade/confirm')) {
        return;
    }
    
    const triggerElement = document.querySelector('.pl-summary__item-content-pc[data-pl="pl-summary-content"]');
    if (triggerElement) {
        main();
        obs.disconnect();
    }
});

pageObserver.observe(document.body, {
    childList: true,
    subtree: true
});
